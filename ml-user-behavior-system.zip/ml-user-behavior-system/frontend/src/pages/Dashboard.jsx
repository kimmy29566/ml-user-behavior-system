export default function Dashboard() {
  return (
    <div>
      <h1>Analytics Dashboard</h1>
    </div>
  )
}
